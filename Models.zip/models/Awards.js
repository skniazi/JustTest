const mongoose = require('mongoose');

const awardSchema = new mongoose.Schema({
	post: {
		type: Schema.Types.ObjectId,
		ref: 'Post'
	},
	achievmentProgress: {
		type: String,
		enum: [ 'First Day', 'First Week' ]
	}
});

module.exports = mongoose.model('Post', awardSchema);
